package control;

import entity.User;

public class MainControl {
	public static User user = null;
}
